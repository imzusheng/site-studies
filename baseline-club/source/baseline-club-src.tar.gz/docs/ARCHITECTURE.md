# Architecture

## Runtime boundary

`tools/build.mjs` embeds the cached Three.js bundle, Rain/Snow GLBs and baked motion JSON into one HTML. The runtime Content Security Policy allows only inline application code and local blob URLs created while parsing embedded GLBs; outbound HTTP(S) is not needed.

## Simulation

The game uses a fixed update clock. `src/physics.js` owns ball state, gravity, drag, spin/Magnus approximation, net contact, court bounce and perimeter walls. Prediction copies the same state and integrates it forward; assists consume this prediction rather than running an alternate ball model.

A missed ball is marked dead for scoring but remains simulated until it settles/ages out. Multiple dead balls may coexist up to a bounded cap.

## Shot output

Default `automatic()` accepts no landing target. It derives racket normal, racket speed, outgoing velocity and spin from the contact state. `targeted()` is an explicit optional mode and solves only the initial launch state; neither mode modifies the ball after launch to reach a goal.

## Characters

`src/characters.js` parses the two embedded GLBs, maps their game deformation skeleton to the 18-joint motion rig, and binds the racket to the dominant wrist. Recorded clips are sampled/interpolated; reach/slice adapt existing clips. CPU and player run through the same visual and ball-contact systems.

## AI opponents

`ClubPhysics.opponents` defines reaction, movement, power, spin, risk/spread, aggression and recovery preferences. AI predicts the incoming ball, moves toward a reachable contact state and chooses a stroke profile; it does not redirect a ball after it is struck.

## Product state

Match, practice and studio are separate application modes. Replay snapshots live pose/ball state, plays from a bounded history, and restores the live state on exit. Settings persist locally. UI assist toggles are independent.

## Performance strategy

- one cached engine bundle, two reusable character assets
- instanced/batched venue geometry where possible
- capped DPR / selectable quality
- bounded ball/dead-ball/replay histories
- bounded prediction horizon
- no runtime character generation or source-BVH conversion

This architecture intentionally favors a small number of high-quality characters over large crowds or film-production facial rigs.
