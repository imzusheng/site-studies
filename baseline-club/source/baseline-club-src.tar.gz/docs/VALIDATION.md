# Validation — Baseline Club 2.0.0-rc2

## Executed evidence

The current deterministic browser acceptance suite passed **41 / 41** checks. Separate behavior checks passed **19 / 19** and the live requestAnimationFrame smoke suite passed **8 / 8**. The test evidence is stored under `artifacts/` in the offline source package and summarized in `docs/validation-summary.json`.

The validated HTML at the time of the full acceptance pass was **9,146,390 bytes** with SHA-256 `1a9e26ef77a0da7cef9927681d0f163dc32dd4110bdce15349c530c6af8cfa2f`. Rebuild and static verification are run again before handoff; if documentation-only changes alter no embedded runtime input, this hash remains unchanged.

### Covered

- embedded offline boot; no external HTTP(S) runtime requests
- Rain and Snow load as game characters with 18 mapped deformation joints and normalized finite skinning
- eight studio choices (six recorded source strokes plus two disclosed derivatives)
- player can switch Rain/Snow
- predicted bounce, recommended position, timing and trajectory assists independently toggle
- missed/dead balls remain visible and physically settle instead of disappearing immediately
- easy / club / pro produce increasing feed pace while gravity remains fixed
- default auto shot landing changes with timing/power; higher power increases outgoing speed
- manual target mode remains distinct and functional
- power opponent is measurably faster than steady opponent; tactician selects slice; visual profiles differ
- bilateral match hitting and point scoring occur from simulated outcomes
- About centralizes player-facing attribution
- 390×844 and 844×390 touch layouts fit without horizontal overflow
- no uncaught JavaScript or WebGL/shader errors in the exercised paths

### Representative simulations

- 90-second match sample: 16 player hits / 10 opponent hits, score 3–7, longest rally 9, ten retained dead balls observed.
- Opponent samples: steady ~56.3 km/h, power ~65.5 km/h; tactician exercised slice/smash selection.
- Mean initial feed pace: easy ~17.3 m/s, club ~19.9 m/s, pro ~21.8 m/s.

## What is not certified

- physical Android/iOS FPS, battery and thermal behavior
- Safari/Firefox parity
- long-session memory stress
- exhaustive garment/body penetration across every interpolated pose
- calibrated real-racket string-bed physics
- complete professional tennis scoring/serve rules
- full Blender Studio production facial/corrective rig parity

Chromium in this environment uses SwiftShader. A live-loop smoke test is useful for state-machine correctness, but its wall-clock speed must not be presented as device performance.

## Repeat with explicit timeout

```bash
node tools/build.mjs
node tools/verify.mjs
node tools/run-bounded.mjs 180000 xvfb-run -a python tests/acceptance.py
```

Do not add or use GitHub Actions for these checks unless explicitly requested.
